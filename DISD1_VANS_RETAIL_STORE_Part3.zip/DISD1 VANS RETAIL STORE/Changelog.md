#Part 2 problems I fixed

1) Stylesheet name: the file was Styles.Css but the pages linked style.css, so the styles would fail on GitHub Pages i made sure to make changes fixing the issue.
2) Paths and srcset: image and video paths didn’t match the Images folder, and srcset pointed at files that don’t exist.
3) Product text: names and alt text didn’t match the pictures. For example “Warped Tour Patch Jacket” was a checkerboard tee and “Off The Wall Tee” was a cap, so I renamed the products to match.
4) Page setup and layout: there was no viewport tag, and the media queries and font import had gone missing. Several unclosed <div> and <video> tags broke the layout.
5) Deploy: push to GitHub and turn on Pages (Settings → Pages → main / root). robots.txt and sitemap.xml.
6) Prices and stock: I made up in Data/catalogue.json.


refrences
1. Vans — Wikipedia. https://en.wikipedia.org/wiki/Vans
2. Vans South Africa | Official Store. https://vans.co.za/
3. How Vans was created? #facts #history #vans. https://www.youtube.com/shorts/b4JHLuebCb0
4. The Story of Vans. https://www.youtube.com/watch?v=p5n2x0ox47w
5. MDN Web Docs — CSS Grid Layout. https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout
6. MDN Web Docs — Responsive images. https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Responsive_images
7. MDN Web Docs — Using media queries. https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries/Using_media_queries
8. Google Fonts. https://fonts.google.com
9. Leaflet — Quick Start Guide. https://leafletjs.com/examples/quick-start/
10. OpenStreetMap — Copyright and License. https://www.openstreetmap.org/copyright
11. jQuery — .slideToggle(). https://api.jquery.com/slidetoggle/
12. MDN Web Docs — Using the Fetch API. https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
13. 666MDN Web Docs — Client-side form validation. https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms/Form_validation

