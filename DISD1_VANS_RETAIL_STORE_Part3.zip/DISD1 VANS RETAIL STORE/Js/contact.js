
(function () {
  'use strict';
 
  const RECIPIENT = 'fatoyinboemmanuel23@gmail.com';
  const MESSAGE_MIN = 10;
  const MESSAGE_MAX = 500;
 
  const form = document.getElementById('contact-form');
  if (!form) { return; }
 
  const messageInput = document.getElementById('contact-message');
  const counter = document.getElementById('message-counter');
  const preview = document.getElementById('email-preview');
  const previewText = document.getElementById('email-preview-text');
  const sendLink = document.getElementById('email-send-link');
 
  function updateCounter() {
    counter.textContent = messageInput.value.length + ' / ' + MESSAGE_MAX + ' characters';
  }
  messageInput.addEventListener('input', updateCounter);
  updateCounter();
 
  const validator = OTW.attachValidation(form, {
    'contact-name':    function (i) { return OTW.rules.name(i.value); },
    'contact-email':   function (i) { return OTW.rules.email(i.value); },
    'contact-phone':   function (i) { return OTW.rules.phone(i.value); },
    'contact-type':    function (i) { return OTW.rules.select(i.value, 'a message type'); },
    'contact-message': function (i) { return OTW.rules.message(i.value, MESSAGE_MIN, MESSAGE_MAX); }
  });
 
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    if (!validator.validateAll()) { return; }
 
    const name = document.getElementById('contact-name').value.trim();
    const email = document.getElementById('contact-email').value.trim();
    const phone = document.getElementById('contact-phone').value.trim();
    const type = document.getElementById('contact-type').value;
    const message = messageInput.value.trim();
 
    const subject = (type + ' from ' + name).replace(/[\r\n]+/g, ' ');
    const body = [
      'Name: ' + name,
      'Email: ' + email,
      'Phone: ' + phone,
      'Message type: ' + type,
      '',
      'Message:',
      message
    ].join('\n');
 
    const mailto = 'mailto:' + RECIPIENT +
      '?subject=' + encodeURIComponent(subject) +
      '&body=' + encodeURIComponent(body);
 
    previewText.textContent = 'To: ' + RECIPIENT + '\nSubject: ' + subject + '\n\n' + body;
    sendLink.href = mailto;
    preview.hidden = false;
    preview.focus();
    window.location.href = mailto;
  });
})();
 
