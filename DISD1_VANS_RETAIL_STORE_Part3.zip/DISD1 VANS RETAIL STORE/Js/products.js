(function () {
  'use strict';
 
  const grid = document.getElementById('product-grid');
  if (!grid) { return; }
 
  const searchInput = document.getElementById('product-search');
  const categorySelect = document.getElementById('product-category');
  const sortSelect = document.getElementById('product-sort');
  const status = document.getElementById('product-status');
 
  let products = [];
  let visible = [];
 
  //Rendering
  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) { node.className = className; }
    if (text !== undefined) { node.textContent = text; }
    return node;
  }
 
  function buildCard(product, index) {
    const figure = el('figure', 'product-item');
 
    const thumb = el('button', 'product-thumb');
    thumb.type = 'button';
    thumb.dataset.index = String(index);
    thumb.setAttribute('aria-label', 'View larger image: ' + product.name);
 
    const img = document.createElement('img');
    img.src = product.image;
    img.alt = product.alt;
    img.width = product.width;
    img.height = product.height;
    img.loading = 'lazy';
    thumb.appendChild(img);
 
    const link = el('a', 'btn', 'Enquire');
    link.href = 'enquiry.html?type=product&item=' + encodeURIComponent(product.id);
 
    figure.append(
      thumb,
      el('figcaption', 'product-caption', product.name),
      el('p', 'product-desc', product.description),
      el('p', 'product-price', OTW.formatPrice(product.price)),
      link
    );
    return figure;
  }
 
  function render(list, animate) {
    visible = list;
    grid.replaceChildren.apply(grid, list.map(buildCard));
    if (animate) { OTW.reveal(grid.children); }
    status.textContent = list.length === 0
      ? 'No products match your search.'
      : list.length + (list.length === 1 ? ' product shown' : ' products shown');
  }
 
  function update() {
    const term = searchInput.value.trim().toLowerCase();
    const category = categorySelect.value;
 
    let list = products.filter(function (p) {
      const matchesText = !term || (p.name + ' ' + p.description + ' ' + p.category).toLowerCase().indexOf(term) !== -1;
      const matchesCategory = category === 'all' || p.category === category;
      return matchesText && matchesCategory;
    });
 
    switch (sortSelect.value) {
      case 'price-asc':  list = list.slice().sort(function (a, b) { return a.price - b.price; }); break;
      case 'price-desc': list = list.slice().sort(function (a, b) { return b.price - a.price; }); break;
      case 'name-asc':   list = list.slice().sort(function (a, b) { return a.name.localeCompare(b.name); }); break;
      default: break;
    }
    render(list, false);
  }
 
  //Lightbox
  let lightbox = null;
  let closeBtn, prevBtn, nextBtn, lbImg, lbCaption;
  let current = 0;
  let lastTrigger = null;
 
  // The viewer is created the first time an image is opened.
  function buildLightbox() {
    lightbox = el('div', 'lightbox');
    lightbox.setAttribute('role', 'dialog');
    lightbox.setAttribute('aria-modal', 'true');
    lightbox.setAttribute('aria-label', 'Image viewer');
 
    closeBtn = el('button', 'lightbox-btn lightbox-close', '\u00D7');
    prevBtn = el('button', 'lightbox-btn lightbox-prev', '\u2039');
    nextBtn = el('button', 'lightbox-btn lightbox-next', '\u203A');
    [closeBtn, prevBtn, nextBtn].forEach(function (b) { b.type = 'button'; });
    closeBtn.setAttribute('aria-label', 'Close image viewer');
    prevBtn.setAttribute('aria-label', 'Previous image');
    nextBtn.setAttribute('aria-label', 'Next image');
 
    const figure = el('figure', 'lightbox-figure');
    lbImg = document.createElement('img');
    lbCaption = el('figcaption', 'lightbox-caption');
    figure.append(lbImg, lbCaption);
    lightbox.append(closeBtn, prevBtn, figure, nextBtn);
    document.body.appendChild(lightbox);
 
    closeBtn.addEventListener('click', close);
    prevBtn.addEventListener('click', function () { show(current - 1); });
    nextBtn.addEventListener('click', function () { show(current + 1); });
    lightbox.addEventListener('click', function (event) { if (event.target === lightbox) { close(); } });
  }
 
  function show(index) {
    const count = visible.length;
    current = (index + count) % count;
    const p = visible[current];
    lbImg.src = p.image;
    lbImg.alt = p.alt;
    lbCaption.textContent = p.name + ' \u2014 ' + OTW.formatPrice(p.price) + '  (' + (current + 1) + ' of ' + count + ')';
    const single = count < 2;
    prevBtn.hidden = single;
    nextBtn.hidden = single;
  }
 
  function open(index, trigger) {
    if (!lightbox) { buildLightbox(); }
    lastTrigger = trigger;
    show(index);
    lightbox.classList.add('open');
    document.body.classList.add('lightbox-open');
    closeBtn.focus();
  }
 
  function close() {
    lightbox.classList.remove('open');
    document.body.classList.remove('lightbox-open');
    if (lastTrigger) { lastTrigger.focus(); }
  }
 
  grid.addEventListener('click', function (event) {
    const thumb = event.target.closest('.product-thumb');
    if (thumb) { open(Number(thumb.dataset.index), thumb); }
  });
 
  document.addEventListener('keydown', function (event) {
    if (!lightbox || !lightbox.classList.contains('open')) { return; }
    if (event.key === 'Escape') { close(); }
    else if (event.key === 'ArrowLeft' && visible.length > 1) { show(current - 1); }
    else if (event.key === 'ArrowRight' && visible.length > 1) { show(current + 1); }
    else if (event.key === 'Tab') {
      const focusable = [closeBtn, prevBtn, nextBtn].filter(function (b) { return !b.hidden; });
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
 
  //Start
  OTW.loadCatalogue()
    .then(function (data) {
      products = data.products;
      render(products, true);
      searchInput.addEventListener('input', update);
      categorySelect.addEventListener('change', update);
      sortSelect.addEventListener('change', update);
    })
    .catch(function () {
      status.textContent = 'The products could not be loaded. Please open this page from the live website or a local web server.';
    });
})();
 