(function () {
  'use strict';
 
  const form = document.getElementById('enquiry-form');
  if (!form) { return; }
 
  const typeSelect = document.getElementById('enquiry-type');
  const itemSelect = document.getElementById('enquiry-item');
  const quantityWrap = document.getElementById('quantity-wrap');
  const quantityInput = document.getElementById('quantity');
  const submitBtn = document.getElementById('enquiry-submit');
  const responseBox = document.getElementById('enquiry-response');
 
  let catalogue = null;
 
  //Dynamic item list
  function fillItems(type, selectedId) {
    itemSelect.replaceChildren();
    const placeholder = new Option('Select an item', '');
    itemSelect.add(placeholder);
 
    if (!catalogue || !type) {
      itemSelect.disabled = true;
      quantityWrap.hidden = true;
      return;
    }
    const list = type === 'product' ? catalogue.products : catalogue.services;
    list.forEach(function (entry) {
      itemSelect.add(new Option(entry.name, entry.id, false, entry.id === selectedId));
    });
    itemSelect.disabled = false;
    quantityWrap.hidden = type !== 'product';
  }
 
  typeSelect.addEventListener('change', function () { fillItems(typeSelect.value, ''); });
 
  OTW.loadCatalogue()
    .then(function (data) {
      catalogue = data;
      const params = new URLSearchParams(window.location.search);
      const type = params.get('type');
      if (type === 'product' || type === 'service') { typeSelect.value = type; }
      fillItems(typeSelect.value, params.get('item') || '');
    })
    .catch(function () {
      showMessage('The catalogue could not be loaded. Please open this page from the live website or a local web server.', 'warn');
    });
 
  //Validation
  const validator = OTW.attachValidation(form, {
    'enquiry-name':  function (i) { return OTW.rules.name(i.value); },
    'enquiry-email': function (i) { return OTW.rules.email(i.value); },
    'enquiry-phone': function (i) { return OTW.rules.phone(i.value); },
    'enquiry-type':  function (i) { return OTW.rules.select(i.value, 'an enquiry type'); },
    'enquiry-item':  function (i) { return OTW.rules.select(i.value, 'an item'); },
    'quantity':      function (i) { return OTW.rules.quantity(i.value); },
    'enquiry-consent': function (i) { return OTW.rules.consent(i.checked); }
  });
 
  //Response
  function showMessage(text, tone) {
    responseBox.replaceChildren();
    const p = document.createElement('p');
    p.className = 'status status-' + tone;
    p.textContent = text;
    responseBox.appendChild(p);
    responseBox.hidden = false;
  }
 
  function addRow(list, label, value) {
    const dt = document.createElement('dt');
    const dd = document.createElement('dd');
    dt.textContent = label;
    dd.textContent = value;
    list.append(dt, dd);
  }
 
  function buildResponse(values, data) {
    responseBox.replaceChildren();
    const heading = document.createElement('h2');
    heading.textContent = 'Thank you, ' + values.name.split(' ')[0];
    const list = document.createElement('dl');
    list.className = 'response-list';
    const status = document.createElement('p');
 
    if (values.type === 'product') {
      const product = data.products.find(function (p) { return p.id === values.item; });
      const enough = values.quantity <= product.stock;
      addRow(list, 'Item', product.name);
      addRow(list, 'Price each', OTW.formatPrice(product.price));
      addRow(list, 'Quantity', String(values.quantity));
      addRow(list, 'Estimated total', OTW.formatPrice(product.price * values.quantity));
      if (product.stock === 0) {
        status.className = 'status status-warn';
        status.textContent = 'Availability: currently out of stock.';
      } else if (enough) {
        status.className = 'status status-ok';
        status.textContent = 'Availability: in stock (' + product.stock + ' available).';
      } else {
        status.className = 'status status-warn';
        status.textContent = 'Availability: only ' + product.stock + ' available. Please lower the quantity.';
      }
    } else {
      const service = data.services.find(function (s) { return s.id === values.item; });
      addRow(list, 'Service', service.name);
      status.className = 'status ' + (service.available ? 'status-ok' : 'status-warn');
      status.textContent = 'Availability: ' + service.note;
    }
 
    responseBox.append(heading, list, status);
    responseBox.hidden = false;
  }
 
  //Submit
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    if (!validator.validateAll()) { return; }
 
    const values = {
      name: document.getElementById('enquiry-name').value.trim(),
      email: document.getElementById('enquiry-email').value.trim(),
      phone: document.getElementById('enquiry-phone').value.trim(),
      type: typeSelect.value,
      item: itemSelect.value,
      quantity: Number(quantityInput.value)
    };
 
    submitBtn.disabled = true;
    submitBtn.textContent = 'Checking\u2026';
 
    // form.action points to the catalogue data file; the request runs in the background.
    OTW.fetchJSON(form.getAttribute('action'))
      .then(function (data) {
        buildResponse(values, data);
        responseBox.focus();
        responseBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      })
      .catch(function () {
        showMessage('Sorry, your enquiry could not be processed. Please try again or use the contact page.', 'warn');
      })
      .then(function () {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Send Enquiry';
      });
  });
})();
 